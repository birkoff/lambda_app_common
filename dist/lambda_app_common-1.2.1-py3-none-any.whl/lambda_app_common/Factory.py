

class ServiceFactory:
    @staticmethod
    def build():
        pass

